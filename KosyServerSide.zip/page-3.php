  <body>
    
  <?php include 'includes/header.php';?>

<main class="container">
  <div class="starter-template text-center">
    <h1>Page 3</h1>
    <p class="lead">Use this document as a way to quickly start any new project.<br> All you get is this text and a mostly barebones HTML document.</p>
  </div>

</main><!-- /.container -->
<?php include 'includes/footer.php';?>
  </body>
</html>
