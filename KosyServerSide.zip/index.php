
<?php
require_once('database.php');

// Get products

$queryProducts = 'SELECT * FROM movie';
$statement = $db->prepare($queryProducts);
$statement->execute();
$movies  = $statement->fetchAll();
$statement->closeCursor();
?>



   
<?php include 'includes/header.php';?>
<main class="container">
  <div class="starter-template text-center">
    <div>
     <?php foreach ($movies as $movie){
      echo "<div class=\"card-group\">
      <div class=\"card\">
     <img src=\" $movie['poster']\"  alt=\" $movie['title'] Poster\">
    <div class=\"card-body\">
      <h5 class=\"card-title\">$movie['title']</h5>
      <p class=\"card-text\"><strong>Producer:</strong>  $movie['producer']</p>
      <p class=\"card-text\"><strong>Release Date:</strong>  $movie['release_date']</p>
      <p class=\"card-text\"><strong>Type:</strong> $movie['type']</p>
      <p class=\"card-text\"><strong>Genre:</strong>$movie['genre']</p>
      <p class=\"card-text\"><strong>Duration:</strong>$movie['duration'];</p>
    </div>
  </div>
    </div>"; }
    ?> 
</div>
  </div>


</main><!-- /.container -->
    

<footer>
  copyright 2023
  dvhdkjefllkgf
    </footer>
    <script src="js/bootstrap.bundle.min.js"></script>
  </body>
</html>
<!-- <?php include 'incldues/footer.php'; ?> -->
