<?php
require_once('database.php');

// Get products
$queryProducts = 'SELECT * FROM artiste';
$statement = $db->prepare($queryProducts);
$statement->execute();
$movies  = $statement->fetchAll();
$statement->closeCursor();
?>


  <body>
  <?php include 'includes/header.php';?>
<ma in class="container">
  <div class="starter-template text-center">
    <div>
    <?php foreach ($movies as $movie):?>
  <div class="card">
     <img src="<?php echo  $movie['picture']; ?>" alt="<?php echo $movie['name']; ?> Picture">
    <div class="card-body">
      <h5 class="card-title"><?php echo  $movie['name']; ?></h5>
      <p class="card-text"><strong>Date of Birth:</strong> <?php echo  $movie['dob']; ?></p>
      <p class="card-text"><strong>Origin:</strong> <?php echo $movie['origin']; ?></p>
      <p class="card-text"><strong>Gender:</strong> <?php echo $movie['gender']; ?></p>
    
    </div>
  </div>
<?php endforeach; ?>
</div>
  </div>


</main><!-- /.container -->
<?php include 'includes/footer.php';?>
  </body>
</html>
