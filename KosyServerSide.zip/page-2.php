
<?php
require_once('database.php');

// Get products
$queryProducts = 'SELECT movie.poster,movie.title,artiste.picture,artiste.name FROM movie join artiste ON movie.movieID=artiste.movieID';
$statement = $db->prepare($queryProducts);
$statement->execute();
$movies  = $statement->fetchAll();
$statement->closeCursor();
?>


  <body>
  <?php include 'includes/header.php';?>

<main class="container">
  <div class="starter-template text-center">
    <div>
    <?php foreach ($movies as $movie ):?>
  <div class="card">
     <img src="<?php echo $movie['poster']; ?>" alt="<?php echo $movie['title']; ?> Poster">
     <img src="<?php echo $movie['picture']; ?>" alt="<?php echo $artist['name']; ?> Picture">
    <div class="card-body">
      <h5 class="card-title"><?php echo $movie['title']; ?></h5>
      <h5 class="card-title"><?php echo $movie['name']; ?></h5>
     </div>
  </div>
<?php endforeach; ?>
</div>
  </div>


</main><!-- /.container -->
<?php include 'includes/footer.php';?>
  </body>
</html>
